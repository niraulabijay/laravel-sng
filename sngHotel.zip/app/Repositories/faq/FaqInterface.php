<?php

namespace App\Repositories\faq;

interface FaqInterface{

    public function activeFaqQuery();

    public function faqWithQues();
    
}
