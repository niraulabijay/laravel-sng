<?php

namespace App\Repositories\destination;

interface DestinationInterface{

    public function activeDestinations();

    public function destinationHasHotels();

}
